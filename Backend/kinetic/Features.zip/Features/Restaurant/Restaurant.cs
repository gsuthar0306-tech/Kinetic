using System.Net.Sockets;
using MongoDB.Bson.Serialization.Attributes;

public class Restaurant
{
    public Object? Id { get; set; }

    public string? Name { get; set; }

    [BsonElement("restaurant_id")]
    public string? RestaurantId { get; set; }

    public string? Cuisine { get; set; }

    public AddressFamily Address { get; set; }
    public string? Borough { get; set; }
    public List<GradeEntry>? Grades { get; set; }
}

public class Address
{
    public string? Building { get; set; }

    [BsonElement("coord")]
    public double[]? Coordinates { get; set; }
    public string? Street { get; set; }

    [BsonElement("zipcode")]
    public string? ZipCode { get; set; }
}

public class GradeEntry
{
    public DateTime Date { get; set; }
    public string? Grade { get; set; }
    public float? Score { get; set; }
}